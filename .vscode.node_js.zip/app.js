// Middleware to parse JSON requests
app.use(express.json());

// Create (POST) a new item
app.post('/items', (req, res) => {
  const newItem = req.body;
  data.push(newItem);
  res.status(201).json(newItem);
});

// Read (GET) all items
app.get('/items', (req, res) => {
  res.json(data);
});

// Read (GET) a specific item by ID
app.get('/items/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const item = data.find((item) => item.id === id);
  if (!item) {
    res.status(404).json({ error: 'Item not found' });
  } else {
    res.json(item);
  }
});

// Update (PUT) an item by ID
app.put('/items/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const updatedItem = req.body;
  const index = data.findIndex((item) => item.id === id);
  if (index === -1) {
    res.status(404).json({ error: 'Item not found' });
  } else {
    data[index] = { ...data[index], ...updatedItem };
    res.json(data[index]);
  }
});

// Delete (DELETE) an item by ID
app.delete('/items/:id', (req, res) => {
      const id = parseInt(req.params.id);
      const index = data.findIndex((item) => item.id === id);
      if (index === -1) {
        res.status(404).json({ error: 'Item not found' });
      } else {
        const deletedItem = data.splice(index, 1);
        res.json(deletedItem[0]);
      }
});
app.post('/signup', [
    body('name').trim().escape().notEmpty().isLength({ min: 3, max: 15 }).withMessage('Name should be max 15 characters long'),
    body('surname').trim().escape().notEmpty().isLength({ min: 4, max: 20 }).withMessage('Surname should be max 20 characters long'),
    body('gender').notEmpty().isIn(['male', 'female']).withMessage('Please select a valid gender'),
    body('username').trim().escape().notEmpty().isLength({ min: 5, max: 15 }).withMessage('Username should have min 5, max 15 characters'),
    body('email').trim().notEmpty().isEmail().withMessage('Invalid Email Address').normalizeEmail(),
    body('password').trim().escape().notEmpty().isLength({ min: 8 }).withMessage('Password should be at least 8 characters long')
        .matches('[0-9]').withMessage('Password should contain a number')
        .matches('[a-z]').withMessage('Password should contain a lowercase letter')
        .matches('[A-Z]').withMessage('Password should contain an uppercase letter')
        .matches(/[\W_]/).withMessage('Password should contain a special character'),
], async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.render('signup', { errors: errors.array() });
    }

    const { name, surname, gender, username, email, password } = req.body;
    const saltRounds = 10;

    try {
        // Check if the username or email already exists
        const existingUser = await query('SELECT * FROM users WHERE username = ? OR email = ?', [username, email]);

        if (existingUser.length > 0) {
            return res.render('signup', { error: 'Username or email already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // Insert the new user into the database
        await query('INSERT INTO users (name, surname, gender, username, email, password) VALUES (?, ?, ?, ?, ?, ?)',
            [name, surname, gender, username, email, hashedPassword]);

        console.log('User registered successfully');
        res.redirect('/login');
    } catch (error) {
        console.error('Error registering user: ', error);
        res.status(500).send('Error registering user');
    }
});


app.post('/login', [
    body('username').trim().escape().notEmpty().withMessage('Username is required'),
    body('password').trim().notEmpty().withMessage('Password is required'),
], async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        res.render('login', { errors: errors.array() });
    }

    const { username, password } = req.body;

    try {
        const user = await query('SELECT * FROM users WHERE username = ?', [username]);

        if (user.length === 0) {
            return res.render('login', { error: 'Invalid username or password' });
        }

        const hashedPassword = user[0].password;
        const passwordMatch = await bcrypt.compare(password, hashedPassword);

        if (passwordMatch) {
            req.session.user = user[0];

            // Render the dashboard view with the user object
            res.render('dashboard', { user: user[0] });
        } else {
            return res.render('login', { error: 'Invalid username or password' });
        }
    } catch (error) {
        console.error('Error during login: ', error);
        res.status(500).send('Error during login');
    }
});




app.listen(port);
console.log(`The server is running on port ${port}`);